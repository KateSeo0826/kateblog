export const environment = {
  production: true,
  apiUrl: 'https://wbe-blogapi.herokuapp.com/api'
};
